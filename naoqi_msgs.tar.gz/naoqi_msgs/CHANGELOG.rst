^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package naoqi_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.7 (2015-03-30)
------------------

0.4.6 (2015-02-27)
------------------
* update repo links in package.xml
* Contributors: Mikael Arguedas

0.4.5 (2015-02-11)
------------------

0.4.4 (2015-01-16)
------------------

0.4.3 (2014-12-14)
------------------
* get the packages to actually conflict with the old versions (nao*)
  The replace tag does not provide a way to uninstall the packages.
  Its use case is different.
* Contributors: Vincent Rabaud

0.4.2 (2014-11-26)
------------------
* update changelogs
* Contributors: Vincent Rabaud

0.4.1 (2014-11-13)
------------------
* fixing imports on microphone sensor
* fixing imports on microphone sensor
* Contributors: Karsten Knese

0.4.0 (2014-11-06)
------------------
* introduce replace tag in package.xml
* naoqi_msgs transfer
* renamed subfolders for naoqi_*
* Contributors: Karsten Knese
